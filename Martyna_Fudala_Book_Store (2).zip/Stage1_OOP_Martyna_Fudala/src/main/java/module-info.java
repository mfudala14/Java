module com.example.stage1_oop_martyna_fudala {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires org.junit.jupiter.api;
    requires junit;
    requires java.sql;


    opens com.example.stage1_oop_martyna_fudala to javafx.fxml;
    exports com.example.stage1_oop_martyna_fudala;
}